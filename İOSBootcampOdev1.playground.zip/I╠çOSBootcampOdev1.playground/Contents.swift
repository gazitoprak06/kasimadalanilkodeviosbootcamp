import UIKit

var ilce : String = "Fatih"
print ("İlçe : \(ilce)")

var kitaAdi : String = "Avrupa"
print ("Kıta Adı : \(kitaAdi)")

var faksNumarasi : Int = 123
print ("Faks Numarası : \(faksNumarasi)")

var postaKodu = 34000
print ("Ankara Posta Kodu : \(postaKodu)")

var instaAdresi : String = "gazitoprak"
print ("Instagram Adresi : \(instaAdresi)")

var calistiginBolum : String = "Bilgisayar Mühendisi"
print ("Çalıştığın Bölüm : \(calistiginBolum)")

var urunMiktari = 123456789
print ("Ürün Miktarı : \(urunMiktari)")

var musteriSoyadi : String = "Cansuyu"
print ("Müşteri Soyadı : \(musteriSoyadi)")

var odemeMiktari = 23
print ("Ödeme Miktarı : \(odemeMiktari) £ ")

var dogumTarihi : String = "6 Aralık 1992"
print ("Doğum Tarihi : \(dogumTarihi)")

var borc : String = "1 Trilyon"
print ("Borç Tutarı : \(borc)")

var medeniHal : String = "Bekar"
print ("Medeni Hal : \(medeniHal)")


var video_Yorumu : String = "Sesine sağlık gardaşım"
print ("Video Yorumu : \(video_Yorumu)")

var odemeSaati : Double = 12.15
print ("Ödeme Saati : \(odemeSaati)")

var eftMiktari = 1500
print ("Eft Miktarı : \(eftMiktari) TL")

var satilanMiktar = 1
print ("Satılan Miktar : \(satilanMiktar)")

var telefonModeli : String = "7 Plus"
print ("Telefon Modeli : \(telefonModeli)")

var dergiAdi : String = "Bilim ve Gelecek"
print ("Dergi Adı : \(dergiAdi)")

var basimTarihi : String = "16 Eylül 2023"
print ("Basım Tarihi : \(basimTarihi)")

var zamMiktari : String = "Yüzde 1"
print ("Zam Miktarı : \(zamMiktari)")

var daireSayisi = 6
print ("Daire Sayısı : \(daireSayisi)")

var enlem : String = "25 B"
print ("Enlem : \(enlem) Derece")

var boylam : String = "29 derece 3 dakika 2 saniye"
print ("Boylam : \(boylam)")

var yemekAdi : String = "Yaprak Sarması"
print ("Yemek Adı : \(yemekAdi)")

var urunFiyati = 234
print ("Ürün Fiyatı : \(urunFiyati) TL")

var sirket : String = "Bilişim"
print ("Şirket Türü : \(sirket)")

var videoAdi : String = "Koca Kafalar"
print ("Video Adı : \(videoAdi)")

var muzikSuresi = 5
print ("Müzik Süresi : \(muzikSuresi)")

var mekanPuani = 7
print ("Mekan Puanı : \(mekanPuani)")

var dosyaAdi : String = "Çalışmalarım"
print ("Dosya Adı : \(dosyaAdi)")

var resimFormati : String = "jpeg"
print ("Resim Formatı : \(resimFormati)")

var renk : String = "Siyah"
print ("Renk : \(renk)")

var renkKodu = 123
print ("Renk Kodu : \(renkKodu)")

var bilgisayarModeli : String = "Macbook Air"
print ("Bilgisayar Modeli : \(bilgisayarModeli)")

var ekranBoyutu :Double = 15.6
print ("Ekran Boyutu : \(ekranBoyutu) İnc")

var kullanimSuresi = 5
print ("Kullanım Süresi : \(kullanimSuresi) Saat")

var basinc : Double = 1.6
print ("Basınç : \(basinc)")

var etkinlikGunu : String = "10 Şubat"
print ("Etkinlik Günü : \(etkinlikGunu)")

var odemeGunu : String = "Ayın 1'i"
print ("Ödeme Günü : \(odemeGunu)")

var yolculukCikisTarihi : String = "17 Eylül"
print ("Yolculuk Çıkış Tarihi : \(yolculukCikisTarihi)")

var mahalleAdi : String = "Çankaya"
print ("Mahalle Adı : \(mahalleAdi)")

var otobusHatti : String = "Ankara - Karabük"
print ("Otobüs Hattı : \(otobusHatti)")

var kullanilanDakika = 2
print ("Kullanılan Dakika : \(kullanilanDakika)")

var kargoTakipNo = 12334567890654
print ("Kargo Takip No : \(kargoTakipNo)")

var kuponSuresi : String = "1 Ay"
print ("Kupon Süresi : \(kuponSuresi)")

var kuponKodu = 123142
print ("Kupon Kodu : \(kuponKodu)")

var faturaTarihi : String = "1 Aralık 2021"
print ("Fatura Tarihi : \(faturaTarihi)")


